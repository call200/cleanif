package com.example.cleanify

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.MotionEvent
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.database.FirebaseDatabase

class Registerpengguna : AppCompatActivity() {
    private lateinit var nameEditText: EditText
    private lateinit var addressEditText: EditText
    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var signUpButton: Button
    private lateinit var checkBox: CheckBox
    private lateinit var loginText: TextView
    private lateinit var googleLogin: ImageView
    private lateinit var facebookLogin: ImageView
    private lateinit var forgotPasswordText: TextView
    private lateinit var auth: FirebaseAuth
    private lateinit var googleSignInClient: GoogleSignInClient

    companion object {
        private const val RC_SIGN_IN = 1001
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registerpengguna)

        // Initialization
        auth = FirebaseAuth.getInstance()
        nameEditText = findViewById(R.id.et_name1)
        addressEditText = findViewById(R.id.et_address)
        emailEditText = findViewById(R.id.et_email)
        passwordEditText = findViewById(R.id.et_password)
        signUpButton = findViewById(R.id.btnSignUp)
        checkBox = findViewById(R.id.checkbox)
        loginText = findViewById(R.id.tv_login)
        googleLogin = findViewById(R.id.btn_google)
        facebookLogin = findViewById(R.id.btn_facebook)
        forgotPasswordText = findViewById(R.id.tv_forgot_password)

        // Google Sign-In config
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build()
        googleSignInClient = GoogleSignIn.getClient(this, gso)

        // Show/Hide password
        passwordEditText.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_UP &&
                event.rawX >= (passwordEditText.right - passwordEditText.compoundPaddingEnd)
            ) {
                val selection = passwordEditText.selectionEnd
                val isVisible = passwordEditText.inputType == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                passwordEditText.inputType = if (isVisible) {
                    InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                } else {
                    InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                }
                passwordEditText.setSelection(selection)
                return@setOnTouchListener true
            }
            false
        }

        // Forgot Password
        forgotPasswordText.setOnClickListener {
            val email = emailEditText.text.toString().trim()
            if (email.isEmpty()) {
                Toast.makeText(this, "Masukkan email untuk reset password", Toast.LENGTH_SHORT).show()
            } else {
                auth.sendPasswordResetEmail(email)
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            Toast.makeText(this, "Link reset dikirim ke email", Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(this, "Gagal kirim reset: ${task.exception?.message}", Toast.LENGTH_LONG).show()
                        }
                    }
            }
        }

        // Navigation to Login
        loginText.setOnClickListener {
            startActivity(Intent(this, Loginpengguna::class.java))
            finish()
        }

        // Sign Up
        signUpButton.setOnClickListener {
            val name = nameEditText.text.toString().trim()
            val address = addressEditText.text.toString().trim()
            val email = emailEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()

            when {
                name.isEmpty() || email.isEmpty() || password.isEmpty() || address.isEmpty() ->
                    Toast.makeText(this, "Semua kolom harus diisi!", Toast.LENGTH_SHORT).show()
                !checkBox.isChecked ->
                    Toast.makeText(this, "Silakan setujui syarat dan ketentuan.", Toast.LENGTH_SHORT).show()
                else -> {
                    auth.createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                val uid = auth.currentUser?.uid.orEmpty()
                                val userData = mapOf(
                                    "Nama" to name,
                                    "Alamat" to address,
                                    "Email" to email
                                )
                                FirebaseDatabase.getInstance().getReference("User")
                                    .child(uid)
                                    .setValue(userData)
                                    .addOnCompleteListener { dbTask ->
                                        if (dbTask.isSuccessful) {
                                            Toast.makeText(this, "Registrasi berhasil!", Toast.LENGTH_LONG).show()
                                            startActivity(Intent(this, MainActivity::class.java))
                                            finish()
                                        } else {
                                            Toast.makeText(this, "Gagal menyimpan ke database: ${dbTask.exception?.message}", Toast.LENGTH_LONG).show()
                                        }
                                    }
                            } else {
                                Toast.makeText(this, "Registrasi gagal: ${task.exception?.message}", Toast.LENGTH_LONG).show()
                            }
                        }
                }
            }
        }

        // Google Login
        googleLogin.setOnClickListener {
            startActivityForResult(googleSignInClient.signInIntent, RC_SIGN_IN)
        }

        // Facebook Login placeholder
        facebookLogin.setOnClickListener {
            Toast.makeText(this, "Login menggunakan Facebook", Toast.LENGTH_SHORT).show()
        }
    }

    // onActivityResult harus di luar onCreate()
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == RC_SIGN_IN) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            try {
                val account = task.getResult(ApiException::class.java)!!
                firebaseAuthWithGoogle(account.idToken!!)
            } catch (e: ApiException) {
                Toast.makeText(this, "Login Google gagal: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun firebaseAuthWithGoogle(idToken: String) {
        val credential = GoogleAuthProvider.getCredential(idToken, null)
        auth.signInWithCredential(credential)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    auth.currentUser?.let { user ->
                        val userData = mapOf(
                            "Nama" to user.displayName,
                            "Email" to user.email
                        )
                        FirebaseDatabase.getInstance().getReference("User")
                            .child(user.uid)
                            .setValue(userData)
                            .addOnCompleteListener { dbTask ->
                                if (dbTask.isSuccessful) {
                                    Toast.makeText(this, "Login berhasil", Toast.LENGTH_SHORT).show()
                                    startActivity(Intent(this, FragmentMenu::class.java))
                                    finish()
                                } else {
                                    Toast.makeText(this, "Gagal menyimpan ke database: ${dbTask.exception?.message}", Toast.LENGTH_LONG).show()
                                }
                            }
                    }
                } else {
                    Toast.makeText(this, "Login gagal: ${task.exception?.message}", Toast.LENGTH_LONG).show()
                }
            }
    }
}
