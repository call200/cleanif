package com.example.cleanify

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import com.example.cleanify.databinding.FragmentMenuBinding

class FragmentMenu : Fragment(R.layout.fragment_menu) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val binding = FragmentMenuBinding.bind(view)

       binding.imgKitchen.setOnClickListener {
            val intent = Intent(activity, Kitchencleaning::class.java)
            startActivity(intent)
        }

        binding.imgtoilet.setOnClickListener {
            val intent = Intent(activity, Toiletcleaning::class.java)
            startActivity(intent)
        }
        binding.imgbedroom.setOnClickListener {
            val intent = Intent(activity, Bedroomcleaningg::class.java)
            startActivity(intent)
        }
        binding.imgwindow.setOnClickListener {
            val intent = Intent(activity, Activity_windowcleaning::class.java)
            startActivity(intent)
        }
        binding.imggarden.setOnClickListener {
            val intent = Intent(activity, Activity_gardencleaning::class.java)
            startActivity(intent)
        }
        binding.imgoffice.setOnClickListener {
            val intent = Intent(activity, Officecleaning::class.java)
            startActivity(intent)
        }
        binding.imgapartment.setOnClickListener {
            val intent = Intent(activity, Apartmentcleaning::class.java)
            startActivity(intent)
        }
        binding.imgmattress.setOnClickListener {
            val intent = Intent(activity, Mattresscleaning::class.java)
            startActivity(intent)
        }
    }
}
