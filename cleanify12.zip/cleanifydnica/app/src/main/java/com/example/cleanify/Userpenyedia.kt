package com.example.cleanify

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class Userpenyedia: AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(R.style.Base_Theme_Cleanify)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_userpenyedia)

        val serviceSeekerButton = findViewById<Button>(R.id.serviceSeekerButton)
        val serviceProviderButton = findViewById<Button>(R.id.serviceProviderButton)
        val loginTextView = findViewById<TextView>(R.id.textViewLogin)


        serviceSeekerButton.setOnClickListener {
            val intent = Intent(this, Registerpengguna::class.java)
            startActivity(intent)
        }

        serviceProviderButton.setOnClickListener {
            val intent = Intent(this, Registrasipenyedia::class.java)
            startActivity(intent)
        }

        loginTextView.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}