package com.example.cleanify

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.constraintlayout.widget.ConstraintLayout
import java.text.NumberFormat
import java.util.Locale

class Bedroomcleaningg : AppCompatActivity() {

    // Property type selection
    private lateinit var cvApartment: CardView
    private lateinit var cvVilla: CardView

    // Home size options
    private lateinit var layoutStudio: ConstraintLayout
    private lateinit var layoutOneBedroom: ConstraintLayout
    private lateinit var layoutTwoBedroom: ConstraintLayout
    private lateinit var layoutThreeBedroom: ConstraintLayout
    private lateinit var layoutFourBedroom: ConstraintLayout

    // Add buttons
    private lateinit var btnAddStudio: Button
    private lateinit var btnAddOneBedroom: Button
    private lateinit var btnAddTwoBedroom: Button
    private lateinit var btnAddThreeBedroom: Button
    private lateinit var btnAddFourBedroom: Button

    // Bottom section
    private lateinit var tvTotalPrice: TextView
    private lateinit var btnContinue: Button

    // Selected options tracking
    private var selectedPropertyType: String? = null
    private var selectedHomeSize: String? = null

    // Price configuration
    private val basePrice = 0 // Start with zero price
    private val propertyTypePrices = mapOf(
        "apartment" to 100000,
        "villa" to 150000
    )
    private val homeSizePrices = mapOf(
        "studio" to 50000,
        "one_bedroom" to 75000,
        "two_bedroom" to 100000,
        "three_bedroom" to 125000,
        "four_bedroom" to 150000
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bedroomcleaningg)

        initViews()
        setupListeners()
        // Don't update price initially - show empty price
        tvTotalPrice.text = "Rp. 0"
    }

    private fun initViews() {
        // Property type
        cvApartment = findViewById(R.id.cv_apartment)
        cvVilla = findViewById(R.id.cv_villa)

        // Home size layouts
        layoutStudio = findViewById(R.id.layout_studio)
        layoutOneBedroom = findViewById(R.id.layout_one_bedroom)
        layoutTwoBedroom = findViewById(R.id.layout_two_bedroom)
        layoutThreeBedroom = findViewById(R.id.layout_three_bedroom)
        layoutFourBedroom = findViewById(R.id.layout_four_bedroom)

        // Add buttons
        btnAddStudio = findViewById(R.id.btn_add_studio)
        btnAddOneBedroom = findViewById(R.id.btn_add_one_bedroom)
        btnAddTwoBedroom = findViewById(R.id.btn_add_two_bedroom)
        btnAddThreeBedroom = findViewById(R.id.btn_add_three_bedroom)
        btnAddFourBedroom = findViewById(R.id.btn_add_four_bedroom)

        // Bottom section
        tvTotalPrice = findViewById(R.id.tv_total_price)
        btnContinue = findViewById(R.id.btn_continue)

        // Set all options to initial state (not selected)
        resetSelections()
    }

    private fun resetSelections() {
        // Reset property type selections
        cvApartment.setCardBackgroundColor(resources.getColor(R.color.white))
        cvVilla.setCardBackgroundColor(resources.getColor(R.color.white))

        // Reset home size selections - all show "Add +" buttons
        btnAddStudio.text = "Add +"
        btnAddStudio.setBackgroundColor(resources.getColor(R.color.blue))

        btnAddOneBedroom.text = "Add +"
        btnAddOneBedroom.setBackgroundColor(resources.getColor(R.color.blue))

        btnAddTwoBedroom.text = "Add +"
        btnAddTwoBedroom.setBackgroundColor(resources.getColor(R.color.blue))

        btnAddThreeBedroom.text = "Add +"
        btnAddThreeBedroom.setBackgroundColor(resources.getColor(R.color.blue))

        btnAddFourBedroom.text = "Add +"
        btnAddFourBedroom.setBackgroundColor(resources.getColor(R.color.blue))

        // Clear selected options
        selectedPropertyType = null
        selectedHomeSize = null
    }

    private fun setupListeners() {
        // Property type selection
        cvApartment.setOnClickListener {
            selectedPropertyType = "apartment"
            cvApartment.setCardBackgroundColor(resources.getColor(R.color.lightGray))
            cvVilla.setCardBackgroundColor(resources.getColor(R.color.white))
            updatePrice()
        }

        cvVilla.setOnClickListener {
            selectedPropertyType = "villa"
            cvVilla.setCardBackgroundColor(resources.getColor(R.color.lightGray))
            cvApartment.setCardBackgroundColor(resources.getColor(R.color.white))
            updatePrice()
        }

        // Home size selection
        btnAddStudio.setOnClickListener {
            selectHomeSize("studio")
        }

        btnAddOneBedroom.setOnClickListener {
            selectHomeSize("one_bedroom")
        }

        btnAddTwoBedroom.setOnClickListener {
            selectHomeSize("two_bedroom")
        }

        btnAddThreeBedroom.setOnClickListener {
            selectHomeSize("three_bedroom")
        }

        btnAddFourBedroom.setOnClickListener {
            selectHomeSize("four_bedroom")
        }

        // Continue button
        btnContinue.setOnClickListener {
            // Navigate to next screen

        }
    }

    private fun selectHomeSize(size: String) {
        // Reset all home size selections
        resetHomeSizeSelections()

        // Set the selected home size
        selectedHomeSize = size

        when (size) {
            "studio" -> {
                btnAddStudio.text = "Added"
                btnAddStudio.setBackgroundColor(resources.getColor(R.color.lightGray))
            }
            "one_bedroom" -> {
                btnAddOneBedroom.text = "Added"
                btnAddOneBedroom.setBackgroundColor(resources.getColor(R.color.lightGray))
            }
            "two_bedroom" -> {
                btnAddTwoBedroom.text = "Added"
                btnAddTwoBedroom.setBackgroundColor(resources.getColor(R.color.lightGray))
            }
            "three_bedroom" -> {
                btnAddThreeBedroom.text = "Added"
                btnAddThreeBedroom.setBackgroundColor(resources.getColor(R.color.lightGray))
            }
            "four_bedroom" -> {
                btnAddFourBedroom.text = "Added"
                btnAddFourBedroom.setBackgroundColor(resources.getColor(R.color.lightGray))
            }
        }

        updatePrice()
    }

    private fun resetHomeSizeSelections() {
        // Reset all home size selections to default state
        btnAddStudio.text = "Add +"
        btnAddStudio.setBackgroundColor(resources.getColor(R.color.blue))

        btnAddOneBedroom.text = "Add +"
        btnAddOneBedroom.setBackgroundColor(resources.getColor(R.color.blue))

        btnAddTwoBedroom.text = "Add +"
        btnAddTwoBedroom.setBackgroundColor(resources.getColor(R.color.blue))

        btnAddThreeBedroom.text = "Add +"
        btnAddThreeBedroom.setBackgroundColor(resources.getColor(R.color.blue))

        btnAddFourBedroom.text = "Add +"
        btnAddFourBedroom.setBackgroundColor(resources.getColor(R.color.blue))
    }

    private fun calculateTotalPrice(): Int {
        var total = basePrice

        // Only calculate price if both property type and home size are selected
        if (selectedPropertyType != null && selectedHomeSize != null) {
            // Add property type price
            total += propertyTypePrices[selectedPropertyType] ?: 0

            // Add home size price
            total += homeSizePrices[selectedHomeSize] ?: 0
        } else {
            // If either one is not selected, return 0
            return 0
        }

        return total
    }

    private fun updatePrice() {
        val total = calculateTotalPrice()
        val formatted = NumberFormat.getCurrencyInstance(Locale("id", "ID")).format(total)
            .replace("IDR", "Rp.")
        tvTotalPrice.text = formatted
    }
}