package com.example.cleanify

import android.content.Intent
import android.os.Bundle
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.util.Log
import android.util.Patterns
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.cleanify.databinding.ActivityRegistrasipenyediaBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase


class Registrasipenyedia : AppCompatActivity() {

    private lateinit var binding: ActivityRegistrasipenyediaBinding
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegistrasipenyediaBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()


        // Tombol daftar diklik
        binding.btnSignup.setOnClickListener {
            val namaLengkap = binding.etName1.text.toString().trim()
            val email = binding.etEmail.text.toString().trim()
            val username = binding.etUsername.text.toString().trim()
            val password = binding.etPassword.text.toString().trim()
            val termsChecked = binding.checkboxTerms.isChecked

            // Validasi input
            if (namaLengkap.isEmpty()) {
                binding.etName1.error = "Nama lengkap harus diisi"
                binding.etName1.requestFocus()
                return@setOnClickListener
            }

            if (email.isEmpty()) {
                binding.etEmail.error = "Email harus diisi"
                binding.etEmail.requestFocus()
                return@setOnClickListener
            }

            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                binding.etEmail.error = "Email tidak valid"
                binding.etEmail.requestFocus()
                return@setOnClickListener
            }

            if (username.isEmpty()) {
                binding.etUsername.error = "Username harus diisi"
                binding.etUsername.requestFocus()
                return@setOnClickListener
            }

            if (password.isEmpty()) {
                binding.etPassword.error = "Password harus diisi"
                binding.etPassword.requestFocus()
                return@setOnClickListener
            }

            if (password.length < 8) {
                binding.etPassword.error = "Password minimal 8 karakter"
                binding.etPassword.requestFocus()
                return@setOnClickListener
            }

            if (!termsChecked) {
                Toast.makeText(
                    this,
                    "Anda harus menyetujui syarat dan ketentuan",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            // Proses Firebase Auth dan simpan ke Realtime Database
            auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        val uid = auth.currentUser?.uid
                        val userData = mapOf(
                            "namaLengkap" to namaLengkap,
                            "email" to email,
                            "username" to username
                        )

                        FirebaseDatabase.getInstance().getReference("Penyedia")
                            .child(uid ?: "")
                            .setValue(userData)
                            .addOnCompleteListener { dbTask ->
                                if (dbTask.isSuccessful) {
                                    Toast.makeText(
                                        this, "Berhasil simpan ke database", Toast.LENGTH_SHORT
                                    ).show()
                                } else {
                                    Toast.makeText(
                                        this,
                                        "Gagal menyimpan ke database: ${dbTask.exception?.message}",
                                        Toast.LENGTH_LONG
                                    ).show()
                                }
                            }
                    }
                }
        }

        // Navigasi ke halaman login
        binding.tvLogin.setOnClickListener {
            startActivity(Intent(this, LoginPenyedia::class.java))
        }

        // Toggle visibilitas password
        binding.etPassword.setOnClickListener {
            togglePasswordVisibility(binding.etPassword)
        }
    }

    private fun togglePasswordVisibility(editText: EditText) {
        val isVisible = editText.transformationMethod is PasswordTransformationMethod
        editText.transformationMethod = if (isVisible) {
            HideReturnsTransformationMethod.getInstance()
        } else {
            PasswordTransformationMethod.getInstance()
        }
        editText.setSelection(editText.text.length)
    }
}
