package com.example.cleanify

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class Registerpengguna : AppCompatActivity() {

    private lateinit var nameEditText: EditText
    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var signUpButton: Button
    private lateinit var checkBox: CheckBox
    private lateinit var loginText: TextView
    private lateinit var googleLogin: ImageView
    private lateinit var facebookLogin: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registerpengguna)


        nameEditText = findViewById(R.id.et_name1)
        emailEditText = findViewById(R.id.et_email)
        passwordEditText = findViewById(R.id.et_password)
        signUpButton = findViewById(R.id.btnSignUp)
        checkBox = findViewById(R.id.checkbox)
        loginText = findViewById(R.id.tv_login)
        googleLogin = findViewById(R.id.btn_google)
        facebookLogin = findViewById(R.id.btn_facebook)


        loginText.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }


        signUpButton.setOnClickListener {
            val name = nameEditText.text.toString().trim()
            val email = emailEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()

            if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Semua kolom harus diisi!", Toast.LENGTH_SHORT).show()
            } else if (!checkBox.isChecked) {
                Toast.makeText(this, "Silakan setujui syarat dan ketentuan.", Toast.LENGTH_SHORT).show()
            } else {

                Toast.makeText(this, "Registrasi berhasil!\nNama: $name\nEmail: $email", Toast.LENGTH_LONG).show()
            }
        }


        googleLogin.setOnClickListener {
            Toast.makeText(this, "Login menggunakan Google", Toast.LENGTH_SHORT).show()
        }


        facebookLogin.setOnClickListener {
            Toast.makeText(this, "Login menggunakan Facebook", Toast.LENGTH_SHORT).show()
        }
    }
}

