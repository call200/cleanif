package com.example.cleanify

import android.content.Intent
import android.os.Bundle
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class Registrasipenyedia : AppCompatActivity() {

    private lateinit var fullNameEditText: EditText
    private lateinit var emailEditText: EditText
    private lateinit var usernameEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var confirmPasswordEditText: EditText
    private lateinit var termsCheckBox: CheckBox
    private lateinit var signupButton: Button
    private lateinit var loginTextView: TextView

    private var passwordVisible = false
    private var confirmPasswordVisible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registrasipenyedia)

        fullNameEditText = findViewById(R.id.et_name1)
        emailEditText = findViewById(R.id.et_email)
        usernameEditText = findViewById(R.id.et_username)
        passwordEditText = findViewById(R.id.et_password)
        termsCheckBox = findViewById(R.id.checkbox_terms)
        signupButton = findViewById(R.id.btn_signup)
        loginTextView = findViewById(R.id.tv_login)

        signupButton.setOnClickListener {
            if (validateInputs()) {
                Toast.makeText(this, "Pendaftaran berhasil!", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, Loginpenyedia::class.java)
                startActivity(intent)
                finish()
            }
        }

        loginTextView.setOnClickListener {
        }
    }

    private fun togglePasswordVisibility(editText: EditText, isVisible: Boolean) {
        if (isVisible) {
            editText.transformationMethod = PasswordTransformationMethod.getInstance()
        } else {
            editText.transformationMethod = HideReturnsTransformationMethod.getInstance()
        }
        editText.setSelection(editText.text.length)
    }

    private fun validateInputs(): Boolean {
        val fullName = fullNameEditText.text.toString().trim()
        val email = emailEditText.text.toString().trim()
        val username = usernameEditText.text.toString().trim()
        val password = passwordEditText.text.toString()
        val confirmPassword = confirmPasswordEditText.text.toString()

        if (fullName.isEmpty()) {
            fullNameEditText.error = "Nama lengkap harus diisi"
            return false
        }

        if (email.isEmpty()) {
            emailEditText.error = "Email harus diisi"
            return false
        }

        if (username.isEmpty()) {
            usernameEditText.error = "Username harus diisi"
            return false
        }

        if (password.isEmpty()) {
            passwordEditText.error = "Password harus diisi"
            return false
        }

        if (password.length < 8) {
            passwordEditText.error = "Password minimal 8 karakter"
            return false
        }

        if (confirmPassword.isEmpty()) {
            confirmPasswordEditText.error = "Konfirmasi password harus diisi"
            return false
        }

        if (password != confirmPassword) {
            confirmPasswordEditText.error = "Password tidak sama"
            return false
        }

        if (!termsCheckBox.isChecked) {
            Toast.makeText(
                this,
                "Anda harus menyetujui syarat dan ketentuan",
                Toast.LENGTH_SHORT
            ).show()
            return false
        }

        return true
    }
}
