package com.example.cleanify

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText

class Pembayaran : AppCompatActivity() {

    private lateinit var radioGroup: RadioGroup
    private lateinit var rbMasterCard: RadioButton
    private lateinit var rbPayPal: RadioButton
    private lateinit var rbCash: RadioButton
    private lateinit var etPromoCode: TextInputEditText
    private lateinit var btnContinue: MaterialButton
    private lateinit var btnBack: MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pembayaran)

        // Inisialisasi komponen UI
        radioGroup = findViewById(R.id.paymentOptions)
        rbMasterCard = findViewById(R.id.rbMasterCard)
        rbPayPal = findViewById(R.id.rbPayPal)
        rbCash = findViewById(R.id.rbCash)
        etPromoCode = findViewById(R.id.etPromoCode)
        btnContinue = findViewById(R.id.btnContinue)
        btnBack = findViewById(R.id.btnBack)

        // Hilangkan centang default (jika belum ingin dipilih otomatis)
        radioGroup.clearCheck()

        // Tombol Continue ditekan
        btnContinue.setOnClickListener {
            val selectedPaymentMethod = when (radioGroup.checkedRadioButtonId) {
                R.id.rbMasterCard -> "MasterCard"
                R.id.rbPayPal -> "PayPal"
                R.id.rbCash -> "Cash"
                else -> null
            }

            val promoCode = etPromoCode.text.toString().trim()

            if (selectedPaymentMethod == null) {
                Toast.makeText(this, "Please select a payment method", Toast.LENGTH_SHORT).show()
            } else {
                // Lakukan aksi lanjut, misalnya kirim ke backend
                Toast.makeText(this,
                    "Selected: $selectedPaymentMethod\nPromo Code: $promoCode",
                    Toast.LENGTH_LONG).show()
            }
        }

        // Tombol Back ditekan
        btnBack.setOnClickListener {
            finish()
        }
    }
}
