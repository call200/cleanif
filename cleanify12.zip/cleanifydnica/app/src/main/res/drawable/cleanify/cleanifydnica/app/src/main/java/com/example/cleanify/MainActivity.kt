package com.example.cleanify

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var loginButton: Button
    private lateinit var rememberCheckBox: CheckBox
    private lateinit var googleLogin: ImageView
    private lateinit var facebookLogin: ImageView
    private lateinit var signupText: TextView

    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        emailEditText = findViewById(R.id.et_email)
        passwordEditText = findViewById(R.id.et_password)
        loginButton = findViewById(R.id.btnSignUp)
        rememberCheckBox = findViewById(R.id.cb_remember)
        googleLogin = findViewById(R.id.btn_google)
        facebookLogin = findViewById(R.id.btn_facebook)
        signupText = findViewById(R.id.tv_signup)


        sharedPreferences = getSharedPreferences("loginPrefs", MODE_PRIVATE)


        val savedEmail = sharedPreferences.getString("email", "")
        val savedPassword = sharedPreferences.getString("password", "")
        val isRemembered = sharedPreferences.getBoolean("remember", false)

        if (isRemembered) {
            emailEditText.setText(savedEmail)
            passwordEditText.setText(savedPassword)
            rememberCheckBox.isChecked = true
        }

        loginButton.setOnClickListener {
            val email = emailEditText.text.toString()
            val password = passwordEditText.text.toString()

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Email dan Password harus diisi!", Toast.LENGTH_SHORT).show()
            } else {
                // Verifikasi login sederhana (ini bisa diganti dengan autentikasi yang lebih kompleks)
                if (email == "user@example.com" && password == "password123") {
                    Toast.makeText(this, "Login Berhasil!", Toast.LENGTH_SHORT).show()

                    // Simpan preferensi jika "Remember Me" dipilih
                    val editor = sharedPreferences.edit()
                    if (rememberCheckBox.isChecked) {
                        editor.putString("email", email)
                        editor.putString("password", password)
                        editor.putBoolean("remember", true)
                    } else {
                        // Jika "Remember Me" tidak dicentang, hapus preferensi
                        editor.clear()
                    }
                    editor.apply()

                    // Pindah ke halaman Beranda setelah login berhasil
                    val intent = Intent(this, Beranda::class.java)
                    startActivity(intent)
                    finish() // Hapus aktivitas login dari stack agar pengguna tidak bisa kembali ke halaman login
                } else {
                    Toast.makeText(this, "Email atau Password salah!", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}