package com.example.cleanify

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Beranda : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_beranda)

        // Mengatur tampilan agar full screen
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility =
                android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                        android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                        android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        }

        // Menyesuaikan padding dengan insets sistem (status bar, navigation bar)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { view, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Tombol notifikasi
        findViewById<CardView>(R.id.notificationButton).setOnClickListener {
            Toast.makeText(this, "Notifikasi dibuka", Toast.LENGTH_SHORT).show()
        }



        // Setup listener untuk semua kategori
        setupCategoryClickListeners()
    }

    private fun setupCategoryClickListeners() {
        setCategoryClick(R.id.kitchen_cleaning_layout, "Kitchen Cleaning", Kitchencleaning::class.java)
        setCategoryClick(R.id.toilet_cleaning_layout, "Toilet Cleaning", Toiletcleaning::class.java)
        setCategoryClick(R.id.bedroom_cleaning_layout, "Bedroom Cleaning", Bedroomcleaningg::class.java)
        setCategoryClick(R.id.window_cleaning_layout, "Window Cleaning", Activity_windowcleaning::class.java)
        setCategoryClick(R.id.garden_cleaning_layout, "Garden Cleaning", Activity_gardencleaning::class.java)
        setCategoryClick(R.id.office_cleaning_layout, "Office Cleaning", Officecleaning::class.java)
        setCategoryClick(R.id.apartment_cleaning_layout, "Apartment Cleaning", Apartmentcleaning::class.java)
        setCategoryClick(R.id.mattress_cleaning_layout, "Mattress Cleaning", Mattresscleaning::class.java)
    }

    private fun setCategoryClick(layoutId: Int, message: String, targetClass: Class<*>) {
        findViewById<LinearLayout>(layoutId).setOnClickListener {
            Toast.makeText(this, "$message dipilih", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, targetClass))
        }
    }
}
