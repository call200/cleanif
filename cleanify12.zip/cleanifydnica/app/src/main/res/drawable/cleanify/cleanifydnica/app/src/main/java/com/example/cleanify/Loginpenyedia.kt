package com.example.cleanify

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class Loginpenyedia : AppCompatActivity() {


    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var googleLoginImage: ImageView
    private lateinit var facebookLoginImage: ImageView
    private lateinit var loginButton: Button
    private lateinit var rememberMeCheckBox: CheckBox
    private lateinit var signInText: TextView
    private lateinit var forgotPasswordText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_loginpenyedia)


        emailEditText = findViewById(R.id.et_email)
        passwordEditText = findViewById(R.id.et_password)
        googleLoginImage = findViewById(R.id.btn_google)
        facebookLoginImage = findViewById(R.id.btn_facebook)
        loginButton = findViewById(R.id.buttonlogin)
        rememberMeCheckBox = findViewById(R.id.cb_remember)
        signInText = findViewById(R.id.tv_signup)
        forgotPasswordText = findViewById(R.id.tv_forgot_password)


        loginButton.setOnClickListener {
            handleLogin()
        }

        googleLoginImage.setOnClickListener {

            Toast.makeText(this, "Google Login clicked", Toast.LENGTH_SHORT).show()
        }

        facebookLoginImage.setOnClickListener {

            Toast.makeText(this, "Facebook Login clicked", Toast.LENGTH_SHORT).show()
        }

        forgotPasswordText.setOnClickListener {

            Toast.makeText(this, "Forgot password clicked", Toast.LENGTH_SHORT).show()
        }

        signInText.setOnClickListener {

            Toast.makeText(this, "Sign In clicked", Toast.LENGTH_SHORT).show()
        }
    }

    private fun handleLogin() {
        val email = emailEditText.text.toString()
        val password = passwordEditText.text.toString()

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill in both fields", Toast.LENGTH_SHORT).show()
        } else {

            Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show()


            if (rememberMeCheckBox.isChecked) {
                Toast.makeText(this, "Remember Me is checked", Toast.LENGTH_SHORT).show()
            }
            val intent = Intent(this, Beranda::class.java)
            startActivity(intent)
        }
    }
}
